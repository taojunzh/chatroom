from datetime import datetime

from bson import ObjectId

from User import User
import pymongo
#myclient = pymongo.MongoClient("mongodb://mongo:27017")  #for docker
myclient = pymongo.MongoClient("mongodb+srv://budong000:budong000@cluster0.nnm9p.mongodb.net/test?authSource=admin&replicaSet=atlas-yunzlk-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true")

db = myclient.user_login_system


import bcrypt

private_room_db = myclient.get_database("private_room_db")
rooms_collection = private_room_db.get_collection("rooms")
room_members_collection = private_room_db.get_collection("room_members")

def add_room(room_name, owner):
    room_id = rooms_collection.insert_one(
        {'name': room_name, 'owner': owner}).inserted_id
    room_members_collection.insert_one(
        {'_id': {'room_id': ObjectId(room_id), 'username': owner}, 'room_name': room_name, 'added_by': owner})
    return room_id

def delete_room(room_id):
    #rooms_collection.remove({'_id': ObjectId(room_id)})
    room_members_collection.remove( {'_id': ObjectId(room_id)})

def get_room(room_id):
    return rooms_collection.find_one({'_id': ObjectId(room_id)})

def add_room_members(room_id, room_name, usernames, added_by):
    room_members_collection.insert_many(
        [{'_id': {'room_id': ObjectId(room_id), 'username': username}, 'room_name': room_name, 'added_by': added_by} for username in usernames])

def get_room_members(room_id):
    return list(room_members_collection.find({'_id.room_id': ObjectId(room_id)}))

def get_rooms_for_user(username):
    return list(room_members_collection.find({'_id.username': username}))

def is_room_member(room_id, username):
    return room_members_collection.count_documents({'_id': {'room_id': ObjectId(room_id), 'username': username}})
# db room end






def registration(display,username,password,salt):
    user = {'dis_name':display,'_id':username,'pass':password,'pass_salt':salt}
    db.users.insert_one(user)

def get_userinfo(username):
    userinfo = db.users.find_one({'_id': username})
    if userinfo:
        return User(userinfo['dis_name'],userinfo['_id'],userinfo['pass'])

def verify(username,password):
    userinfo = db.users.find_one({'_id': username})
    salt =userinfo['pass_salt']
    hash = userinfo['pass']
    if bcrypt.hashpw(password,salt) == hash:
        return True
    else :
        return False

def validate_dis(display):
    if db.users.find_one({'dis_name': display}):
        return False
    else:
        return True

def validate_user(username):
    if db.users.find_one({'username': username}):
        return False
    else:
        return True
