
from flask import Flask, jsonify, render_template,redirect,url_for,request,session, flash, send_from_directory

from flask_login import current_user, login_user, login_required, logout_user, LoginManager
from flask_socketio import SocketIO,join_room,leave_room

import requests
import datetime
from database import registration, verify, get_userinfo, validate_dis, validate_user, add_room_members, add_room, \
    get_rooms_for_user, is_room_member, get_room, get_room_members
import bcrypt
import os
from pymongo.errors import DuplicateKeyError

#from passlib.hash import pbkdf2_sha256
#chat_history_database.drop()
FolderPath = 'C:\\Users\\Liang\\Desktop\\cse312Project\\chatroom\\static\\Files'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = FolderPath
app.config['SECRET_KEY'] = 'secret!'

socketio = SocketIO(app,cors_allowed_origins="*")
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)
Online_Users = []




@app.route('/')
def index():
    rooms = []
    if current_user.is_authenticated:
        rooms = get_rooms_for_user(current_user.username)
        if current_user.display not in Online_Users:
            Online_Users.append(current_user.display)
    return render_template('index.html', rooms=rooms)



@app.route("/logout/")
@login_required
def logout():
    Online_Users.remove(current_user.display)
    logout_user()
    return redirect(url_for('index'))


@app.route('/chatroom')
def chatroom():
    return render_template('chatroom.html')


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    message =''
    if request.method == 'POST':
        display = request.form.get('display')
        username = request.form.get('username')
        password = request.form.get('password').encode('utf-8')
        salt = bcrypt.gensalt()
        hashed = bcrypt.hashpw(password, salt)
        if validate_dis(display) and validate_user(username):
            registration(display,username,hashed,salt)
            return redirect(url_for('login'))
        else:
            message= "User or displayname existed"
    return render_template('register.html', msg = message)


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    message = ''
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password').encode('utf-8')
        user = get_userinfo(username)
        if user and verify(username,password):
            login_user(user)
            return redirect(url_for('index'))
        else:
            message ="Invalid username or password. Please try again."
    return render_template('login.html',error = message)

# @app.route("/chatroom", methods=["GET", "POST"])
# def chatroom():
#     return render_template('chatroom.html')

@app.route('/setting', methods = ['GET', 'POST'])
def setting():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']

        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)

        if file and ('.' in file.filename and file.filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS): #check for picture extensions
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], file.filename))
            return redirect(url_for('uploaded_file', filename=file.filename))
    return render_template('setting.html')

@app.route('/chatroom/static/Files/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


#private room

# @app.route("/delete", methods=["GET", "POST"])
# def delete(room_id):
#     delete_room(room_id)
#     print("delete room")
#     return render_template('index.html')

@app.route('/create-room/', methods=['GET', 'POST'])
@login_required
def create_room():
    message = ''
    if request.method == 'POST':
        room_name = request.form.get('room_name')
        usernames = [username for username in request.form.get('members').split(' ')]
        if len(room_name) >= 1:
            room_id = add_room(room_name, current_user.username)
            if current_user.username in usernames:
                usernames.remove(current_user.username)
            add_room_members(room_id, room_name, usernames, current_user.username)
            return redirect(url_for('view_room', room_id=room_id))
        else:
            message = "Creating room Failed: Please include a room name "
    return render_template('create_room.html', message=message)

@app.route('/rooms/<room_id>/')
@login_required
def view_room(room_id):
    room = get_room(room_id)
    if room and is_room_member(room_id, current_user.username):
        room_members = get_room_members(room_id)
        return render_template('view_room.html', username=current_user.username, room=room, room_members=room_members)
    else:
        return "Join room failed", 404

@socketio.on('send_message')
def handle_send_message_event(data):
    data["message"] = HTMLescape(data["message"])
    socketio.emit('receive_message', data, room = data['room'])

@socketio.on('join_room')
def handle_join_room_event(data):
    join_room(data['room'])
    socketio.emit('join_room_announcement', data, room = data['room'])

@socketio.on('leave_room')
def handle_leave_room_event(data):
    leave_room(data['room'])
    socketio.emit('leave_room_announcement', data, room = data['room'])
#private room ends

@socketio.on('connect')
def connect_handler():
    if current_user.is_authenticated:
        user = current_user.display
        print(Online_Users)
        socketio.emit('add user',(user,Online_Users))
    else:
        return False

@socketio.on("disconnect")
def disconnect():
    logout_user()

@socketio.on("message")
def message(data):
    if(data["type"] == "comment"):
        socketio.send({
            'username': data["username"],
            'comment': HTMLescape(data["comment"]),
            "type": data["type"],
            'time': datetime.datetime.now().strftime("%m/%d/%Y %H:%M:%S")
        })
    if(data["type"] == "link"):
        embedded = data["link"].replace(
            "https://www.youtube.com/watch?v=", "https://www.youtube.com/embed/")
        if "&ab_channel=" in embedded:
            embedded = embedded.split("&ab_channel=")
            embedded = embedded[0]

        socketio.send({
            'username': data["username"],
            'link': HTMLescape(data["link"]),
            'embedded': HTMLescape(embedded),
            'valid': check_url(data["link"]),
            "type": data["type"],
            'time': datetime.datetime.now().strftime("%m/%d/%Y %H:%M:%S")
        })


def HTMLescape(string):
    return string.replace("&", "&amp").replace("<", "&lt").replace(">", "&gt")


def check_url(url):
    try:
        response = requests.head(url)
        return 1 if (200 == response.status_code and "youtube.com" in url)else 0
    except:
        return 0


@login_manager.user_loader
def load_user(user_id):
    return get_userinfo(user_id)


if __name__ == '__main__':

    socketio.run(app, debug=True)

    #socketio.run(app, host="0.0.0.0", port=5000, debug=True) #use this line when using docker
