# chatroom

1. Install flask_socket, flask_sqlalchemy,flask,eventlet
2. After running the test.py, please navigate to http://127.0.0.1:5000/
